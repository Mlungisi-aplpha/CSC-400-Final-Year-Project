 <?php
// TURN ON ERROR REPORTING (Remove these 2 lines when going live)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Database Connection
 $host = "127.0.0.1";
 $db_name = "ok_grocer_db";
 $username = "root";
 $password = ""; // If you set a password for phpMyAdmin root, put it here!

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode(["status" => "error", "message" => "DB Connection failed: " . $e->getMessage()]);
    exit;
}

// Simple Router (XAMPP Compatible)
 $endpoint = isset($_GET['endpoint']) ? $_GET['endpoint'] : '';
 $method = $_SERVER['REQUEST_METHOD'];
 $input = json_decode(file_get_contents('php://input'), true);

switch($endpoint) {
    case 'login':
        if ($method === 'POST') handleLogin($pdo, $input);
        break;
    case 'products':
        handleGetProducts($pdo);
        break;
    case 'request-otp':
        if ($method === 'POST') handleRequestOTP($pdo, $input);
        break;
    case 'pay':
        if ($method === 'POST') handleProcessSale($pdo, $input);
        break;
    case 'daily-sales':
        handleDailySales($pdo);
        break;
    case 'admin-stats':
        handleAdminStats($pdo);
        break;
    case 'add-product':
        if ($method === 'POST') handleAddProduct($pdo, $input);
        break;
    case 'edit-product':
        if ($method === 'POST') handleEditProduct($pdo, $input);
        break;
    case 'delete-product':
        if ($method === 'DELETE') handleDeleteProduct($pdo, $_GET['id'] ?? null);
        break;
    case 'restock':
        if ($method === 'POST') handleRestock($pdo, $input);
        break;
    default:
        echo json_encode(["status" => "error", "message" => "Invalid API endpoint"]);
}

// 1. LOGIN
function handleLogin($pdo, $data) {
    $username = $data['username'] ?? '';
    $password = $data['password'] ?? '';
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        $log = $pdo->prepare("INSERT INTO audit_logs (user_name, action_type, details) VALUES (?, 'LOGIN', ?)");
        $log->execute([$user['cashier_name'], 'User logged in successfully']);
        echo json_encode(["status" => "success", "user" => ["id" => $user['id'], "cashier_name" => $user['cashier_name'], "role" => $user['role']]]);
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid credentials"]);
    }
}

// 2. GET PRODUCTS
function handleGetProducts($pdo) {
    $stmt = $pdo->query("SELECT p.id, p.product_name as name, p.product_name, p.barcode, p.price, p.original_price, p.is_promo, p.is_vat_exempt, IFNULL(s.quantity, 0) as current_stock FROM products p LEFT JOIN stock s ON p.id = s.product_id ORDER BY p.product_name ASC");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
}

// 3. REQUEST OTP
function handleRequestOTP($pdo, $data) {
    $phone = $data['phone_number'] ?? '';
    $provider = $data['provider'] ?? '';
    $otp = rand(1000, 9999);
    $stmt = $pdo->prepare("INSERT INTO payment_verifications (phone_number, provider, otp_code, status) VALUES (?, ?, ?, 'pending')");
    if($stmt->execute([$phone, $provider, $otp])) echo json_encode(["status" => "success", "message" => "OTP Generated"]);
    else echo json_encode(["status" => "error", "message" => "Failed to generate OTP"]);
}

// 4. PROCESS SALE
function handleProcessSale($pdo, $data) {
    $total_amount = $data['total_amount'] ?? 0;
    $payment_method = $data['payment_method'] ?? 'Cash';
    $items = $data['items'] ?? [];
    $cashier_id = $data['cashier_id'] ?? 1;
    $customer_phone = $data['customer_phone'] ?? 'WALK_IN';
    $otp_code = $data['otp_code'] ?? '';
    $vat_amount = 0;
    
    foreach($items as $item) {
        if (isset($item['is_vat_exempt']) && $item['is_vat_exempt'] != 1) {
            $vat_amount += ($item['price'] * $item['qty']) - (($item['price'] * $item['qty']) / 1.15);
        }
    }

    $pdo->beginTransaction();
    try {
        if ($payment_method !== 'Cash' && $payment_method !== 'Bank Card') {
            $checkOtp = $pdo->prepare("SELECT id FROM payment_verifications WHERE phone_number = ? AND otp_code = ? AND status = 'pending' ORDER BY created_at DESC LIMIT 1");
            $checkOtp->execute([$customer_phone, $otp_code]);
            if ($checkOtp->rowCount() === 0 && $otp_code !== 'BYPASS') {
                throw new Exception("Invalid or expired OTP");
            }
            $pdo->prepare("UPDATE payment_verifications SET status = 'completed' WHERE phone_number = ? AND otp_code = ?")->execute([$customer_phone, $otp_code]);
        }

        $stmt = $pdo->prepare("INSERT INTO sales (total_amount, vat_amount, payment_method, cashier_id, customer_phone) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$total_amount, $vat_amount, $payment_method, $cashier_id, $customer_phone]);
        $sale_id = $pdo->lastInsertId();

        $receipt_items = "";
        foreach($items as $item) {
            $sub = $item['price'] * $item['qty'];
            $pdo->prepare("INSERT INTO sales_items (sale_id, product_id, qty_sold, price_per_unit) VALUES (?, ?, ?, ?)")->execute([$sale_id, $item['id'], $item['qty'], $item['price']]);
            $pdo->prepare("UPDATE stock SET quantity = quantity - ? WHERE product_id = ?")->execute([$item['qty'], $item['id']]);
            $pdo->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity, reference_id, created_by) VALUES (?, 'SALE', ?, ?, ?)")->execute([$item['id'], $item['qty'], $sale_id, $cashier_id]);
            $receipt_items .= "<tr><td>".htmlspecialchars($item['name'])." x{$item['qty']}</td><td style='text-align:right;'>E" . number_format($sub, 2) . "</td></tr>";
        }
        $pdo->commit();

        $receipt_html = "<div style='width:300px; font-family: monospace; padding: 15px; border: 1px dashed #555;'><h2 style='text-align:center; margin:0;'>OK SUPERMARKET</h2><p style='text-align:center; margin:5px 0 15px; font-size:12px; color:#666;'>Thank you for shopping with us!</p><hr style='border:0; border-top:1px dashed #555;'><table style='width:100%; font-size:14px;'>$receipt_items</table><hr style='border:0; border-top:1px dashed #555;'><table style='width:100%; font-size:14px; font-weight:bold;'><tr><td>TOTAL</td><td style='text-align:right;'>E" . number_format($total_amount, 2) . "</td></tr><tr><td>VAT incl.</td><td style='text-align:right;'>E" . number_format($vat_amount, 2) . "</td></tr><tr><td>Method</td><td style='text-align:right;'>$payment_method</td></tr></table><hr style='border:0; border-top:1px dashed #555;'><p style='text-align:center; font-size:12px; margin-top:10px;'>Sale ID: #$sale_id<br>" . date('Y-m-d H:i:s') . "</p></div>";
        
        echo json_encode(["status" => "success", "receipt" => $receipt_html, "sale_id" => $sale_id]);
    } catch(Exception $e) {
        $pdo->rollBack();
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

// 5. DAILY SALES
function handleDailySales($pdo) {
    $stmt = $pdo->query("SELECT s.id, s.payment_method, s.total_amount, s.sale_date, u.cashier_name FROM sales s LEFT JOIN users u ON s.cashier_id = u.id WHERE DATE(s.sale_date) = CURDATE() ORDER BY s.id DESC");
    echo json_encode(["sales" => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

// 6. ADMIN STATS
function handleAdminStats($pdo) {
    $stmt = $pdo->query("SELECT SUM(total_amount) as revenue, SUM(vat_amount) as tax, COUNT(id) as transactions FROM sales WHERE DATE(sale_date) = CURDATE()");
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$stats['revenue']) $stats['revenue'] = 0; 
    if (!$stats['tax']) $stats['tax'] = 0; 
    if (!$stats['transactions']) $stats['transactions'] = 0;
    echo json_encode(["status" => "success", "stats" => $stats]);
}

// 7. ADD PRODUCT
function handleAddProduct($pdo, $data) {
    $name = $data['name'] ?? '';
    $barcode = $data['barcode'] ?? null;
    $price = $data['price'] ?? 0;
    $stock = $data['stock'] ?? 0;
    $is_vat_exempt = $data['is_vat_exempt'] ?? 0;
    
    $pdo->beginTransaction();
    try {
        $pdo->prepare("INSERT INTO products (product_name, barcode, price, is_vat_exempt) VALUES (?, ?, ?, ?)")->execute([$name, $barcode, $price, $is_vat_exempt]);
        $product_id = $pdo->lastInsertId();
        $pdo->prepare("INSERT INTO stock (product_id, quantity) VALUES (?, ?)")->execute([$product_id, $stock]);
        $pdo->commit();
        echo json_encode(["status" => "success"]);
    } catch(Exception $e) { 
        $pdo->rollBack(); 
        echo json_encode(["status" => "error", "message" => $e->getMessage()]); 
    }
}

// 8. EDIT PRODUCT
function handleEditProduct($pdo, $data) {
    $barcode = $data['barcode'] ?? null;
    $stmt = $pdo->prepare("UPDATE products SET product_name = ?, barcode = ?, price = ?, is_vat_exempt = ? WHERE id = ?");
    $stmt->execute([$data['new_name'] ?? '', $barcode, $data['new_price'] ?? 0, $data['is_vat_exempt'] ?? 0, $data['product_id'] ?? 0]);
    echo json_encode(["status" => "success"]);
}

// 9. DELETE PRODUCT
function handleDeleteProduct($pdo, $id) {
    if (!$id) { echo json_encode(["status" => "error", "message" => "No ID provided"]); return; }
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
    echo json_encode(["status" => "success"]);
}

// 10. RESTOCK
function handleRestock($pdo, $data) {
    $product_id = $data['product_id'] ?? 0;
    $quantity = $data['quantity'] ?? 0;
    $user_name = $data['user_name'] ?? 'System';
    
    $uStmt = $pdo->prepare("SELECT id FROM users WHERE cashier_name = ?"); 
    $uStmt->execute([$user_name]); 
    $userId = $uStmt->fetchColumn() ?? 1;
    
    $pdo->beginTransaction();
    try {
        $pdo->prepare("UPDATE stock SET quantity = quantity + ? WHERE product_id = ?")->execute([$quantity, $product_id]);
        $pdo->prepare("INSERT INTO stock_movements (product_id, movement_type, quantity, created_by) VALUES (?, 'PURCHASE', ?, ?)")->execute([$product_id, $quantity, $userId]);
        $pdo->commit(); 
        echo json_encode(["status" => "success"]);
    } catch(Exception $e) { 
        $pdo->rollBack(); 
        echo json_encode(["status" => "error", "message" => $e->getMessage()]); 
    }
}
?>