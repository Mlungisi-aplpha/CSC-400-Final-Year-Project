const API = {
    async post(endpoint, body) {
        try {
            const response = await fetch(endpoint, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                credentials: 'include',
                body: JSON.stringify(body)
            });
            const data = await response.json();
            if (response.status === 401) {
                window.dispatchEvent(new CustomEvent('session-expired'));
            }
            return data;
        } catch (err) {
            console.error(`API Error [POST ${endpoint}]:`, err);
            return { status: 'error', message: 'Network failure. Check connection and retry.' };
        }
    },

    async get(endpoint) {
        try {
            const response = await fetch(endpoint, {
                credentials: 'include'
            });
            const data = await response.json();
            if (response.status === 401) {
                window.dispatchEvent(new CustomEvent('session-expired'));
            }
            return data;
        } catch (err) {
            console.error(`API Error [GET ${endpoint}]:`, err);
            return { status: 'error', message: 'Network failure. Check connection and retry.' };
        }
    },

    login: (username, password) => API.post('/api/login', { username, password }),
    getSession: () => API.get('/api/session'),
    logout: () => API.post('/api/logout', {}),
    openDrawer: (opening_balance) => API.post('/api/drawer/open', { opening_balance }),
    closeDrawer: (closing_balance) => API.post('/api/drawer/close', { closing_balance }),
    getDrawerStatus: () => API.get('/api/drawer/status'),
    getProducts: () => API.get('/api/products'),
    requestOtp: (phone_number, provider) => API.post('/api/request-otp', { phone_number, provider }),
    processSale: (payload) => API.post('/api/pay', payload),
    getDailySales: () => API.get('/api/daily-sales'),
    getSaleDetail: (id) => API.get(`/api/sale/${id}`),
    lookupCustomer: (phone) => API.get(`/api/customers?phone=${encodeURIComponent(phone)}`),
    getStats: () => API.get('/api/admin/stats'),
    restock: (product_id, quantity, user_name) => API.post('/api/restock', { product_id, quantity, user_name }),
    setPromotion: (product_id, promo_price, user_name) => API.post('/api/admin/set-promotion', { product_id, promo_price, user_name }),
    addProduct: (name, price, stock, is_vat_exempt) => API.post('/api/admin/add-product', { name, price, stock, is_vat_exempt }),
    editProduct: (product_id, new_name, new_price, is_vat_exempt, user_name) => API.post('/api/admin/edit-product', { product_id, new_name, new_price, is_vat_exempt, user_name }),
    deleteProduct: (id) => fetch(`/api/admin/delete-product/${id}`, { method: 'DELETE', credentials: 'include' }).then(r => r.json()),
    processRefund: (sale_id, reason) => API.post('/api/admin/refund', { sale_id, reason })
};

const UI = {
    currency: (amount) => `E${parseFloat(amount).toFixed(2)}`,
    escapeHtml: (text) => { const d = document.createElement('div'); d.textContent = text; return d.innerHTML; }
};