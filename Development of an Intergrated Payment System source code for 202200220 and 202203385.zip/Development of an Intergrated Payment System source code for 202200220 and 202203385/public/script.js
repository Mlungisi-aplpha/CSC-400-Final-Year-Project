let products = [], cart = [], total = 0;

// Initial Load
window.onload = async () => {
    await loadProducts();
    setupSearch();
};

async function loadProducts() {
    try {
        const res = await fetch('/api/products');
        const data = await res.json();
        products = data.sort((a, b) => {
            const nameA = a.name || a.product_name || "";
            const nameB = b.name || b.product_name || "";
            return nameA.localeCompare(nameB);
        });
        renderSuggestions(products);
        if (typeof renderInventoryList === "function") renderInventoryList();
    } catch (e) { console.error("Sync error:", e); }
}

// --- SALES & CART ---
function setupSearch() {
    const input = document.getElementById('itemSearch');
    if (!input) return;
    input.oninput = (e) => {
        const val = e.target.value.toLowerCase().trim();
        const filtered = products.filter(p => {
            const pName = p.name || p.product_name || "";
            return pName.toLowerCase().includes(val);
        });
        renderSuggestions(filtered);
    };
}

function renderSuggestions(list) {
    const suggest = document.getElementById('searchSuggestions');
    if (!suggest) return;
    suggest.innerHTML = list.map(p => {
        const productName = p.name || p.product_name || "Unknown Product";
        const isSale = p.is_promo === 1;
        const stock = p.current_stock || 0;
        return `
            <div class="suggest-item" onclick="addToCart(${p.id})" style="${isSale ? 'border-left: 4px solid #f59e0b;' : ''}">
                <span>
                    ${productName}
                    ${isSale ? '<small style="color:#f59e0b; font-weight:bold;"> [SALE]</small>' : ''}
                    <small style="${stock <= 5 ? 'color:red' : 'color:gray'}">(${stock} left)</small>
                </span>
                <span style="float:right; font-weight:bold; ${isSale ? 'color:#ea580c;' : ''}">E${parseFloat(p.price).toFixed(2)}</span>
            </div>
        `;
    }).join('');
}

function addToCart(id) {
    const p = products.find(x => x.id == id);
    if (!p) return;
    
    if ((p.current_stock || 0) <= 0) {
        alert("Out of Stock");
        return;
    }

    const exists = cart.find(i => i.id == id);
    if (exists) {
        exists.qty++;
    } else {
        cart.push({
            id: p.id,
            name: p.name || p.product_name,
            price: parseFloat(p.price),
            qty: 1,
            is_vat_exempt: p.is_vat_exempt
        });
    }
    
    const searchInput = document.getElementById('itemSearch');
    if (searchInput) searchInput.value = "";
    const suggest = document.getElementById('searchSuggestions');
    if (suggest) suggest.style.display = 'none';
    
    updateUI();
}

function updateUI() {
    const cartList = document.getElementById('cartList') || document.getElementById('cartBody');
    let currentVat = 0;
    let currentTotal = 0;

    if (cartList) {
        cartList.innerHTML = cart.map(item => {
            const itemSubtotal = item.price * item.qty;
            currentTotal += itemSubtotal;
            const isExempt = (item.is_vat_exempt == 1 || item.is_vat_exempt === true);

            if (!isExempt) {
                const vatAmount = itemSubtotal - (itemSubtotal / 1.15);
                currentVat += vatAmount;
            }

            return `
                <div class="cart-item" style="display:flex; justify-content:space-between; padding:5px; border-bottom:1px solid #eee;">
                    <span>
                        ${item.name} (x${item.qty})
                        ${isExempt ? '<b style="color:#0ea5e9; margin-left:5px;">[EXEMPT]</b>' : ''}
                    </span>
                    <span>E${itemSubtotal.toFixed(2)}</span>
                </div>
            `;
        }).join('');
    } else {
        currentTotal = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);
    }
    
    total = currentTotal;
    
    const totalEl = document.getElementById('totalAmount') || document.getElementById('displayTotal');
    if (totalEl) totalEl.innerText = total.toFixed(2);
    
    const vatEl = document.getElementById('displayVAT');
    if (vatEl) vatEl.innerText = currentVat.toFixed(2);

    // Sync state for external cash terminal layout calculations if applicable
    const tenderedEl = document.getElementById('tendered');
    const displayChangeEl = document.getElementById('displayChange');
    if (tenderedEl && displayChangeEl) {
        const tendered = parseFloat(tenderedEl.value) || 0;
        displayChangeEl.innerText = Math.max(0, tendered - total).toFixed(2);
    }
    const cashBtn = document.getElementById('cashBtn');
    if (cashBtn && tenderedEl) {
        const tendered = parseFloat(tenderedEl.value) || 0;
        cashBtn.disabled = !(total > 0 && tendered >= total);
    }
}

// --- CHECKOUT & ESWATINI ROUTING RULES ---
async function completeSale(method) {
    if (cart.length === 0) return alert("🛒 Cart is empty!");
    
    let phone = "CASH_SALE";
    let otp_code = "BYPASS";
    
    // Check if the payment method requires a customer mobile verification sequence
    if (['MoMo', 'MTN MoMo', 'eMali', 'InstaCash', 'Unayo'].includes(method)) {
        phone = prompt(`Enter 8-digit Eswatini Phone Number for ${method}:`);
        if (!phone) return; // Exit if cancelled
        
        phone = phone.trim();
        
        // 1. Enforce physical length constraint
        if (phone.length !== 8 || isNaN(phone)) {
            return alert("❌ Invalid format!\nPhone number must be exactly 8 digits long.");
        }
        
        const prefix = phone.substring(0, 2);
        
        // 2. Strict Local Mobile Carrier Validation Layer
        if ((method === 'MoMo' || method === 'MTN MoMo') && prefix !== '76' && prefix !== '78') {
            return alert("❌ Validation Error:\nMTN MoMo accounts use 76 or 78 prefixes only.");
        }
        if (method === 'eMali' && prefix !== '79') {
            return alert("❌ Validation Error:\neMali accounts use 79 prefixes only.");
        }
        if (['InstaCash', 'Unayo'].includes(method) && prefix !== '78' && prefix !== '79') {
            return alert(`❌ Validation Error:\n${method} accounts use 78 or 79 prefixes only.`);
        }

        otp_code = prompt(`Enter 4-digit verification OTP code sent to ${phone}:`);
        if (!otp_code) return;
        otp_code = otp_code.trim();
    } else if (['Bank Card', 'Card'].includes(method)) {
        phone = prompt("Enter Bank Card Authorization Code from POS slip:");
        if (!phone) return;
        phone = phone.trim();
    } else {
        if (!confirm(`Confirm ${method} Sale of E${total.toFixed(2)}?`)) return;
    }

    const payload = {
        total_amount: total,
        payment_method: method,
        items: cart,
        cashier_id: (window.activeCashier && window.activeCashier.id) ? window.activeCashier.id : 1,
        cashier_name: (window.activeCashier && window.activeCashier.cashier_name) ? window.activeCashier.cashier_name : "System Terminal",
        customer_phone: phone,
        otp_code: otp_code
    };

    try {
        const res = await fetch('/api/pay', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const result = await res.json();
        
        if (result.status === 'success') {
            const win = window.open('', '_blank', 'width=350,height=600');
            win.document.write('<html><head><title>OK Supermarket Receipt</title>');
            win.document.write('<style>body{margin:0;padding:10px;font-family:monospace;}</style></head><body>');
            win.document.write(result.receipt ? result.receipt : `<pre>Sale Success\nTotal: E${total.toFixed(2)}</pre>`);
            win.document.write('</body></html>');
            
            win.document.close();
            win.focus();
            
            setTimeout(() => {
                win.print();
                win.close();
                
                cart = []; 
                const tenderedInput = document.getElementById('tendered');
                if (tenderedInput) tenderedInput.value = "";
                updateUI(); 
                loadProducts();
                alert("✅ Sale Processed Successfully!");
            }, 500);
        } else {
            alert(`⚠️ TRANSACTION DECLINED:\n\n${result.message || 'Database rule restriction encountered.'}`);
        }
    } catch (err) {
        alert("❌ Terminal server communication error. Please check system context.");
    }
}

// --- ADMIN MODAL LOGIC (ADD/EDIT) ---
function openPOSModal(headerText, color) {
    const modal = document.getElementById('posModal') || document.getElementById('inventoryModal');
    if (!modal) return;
    const header = document.getElementById('posModalHeader');
    if (header) {
        header.innerText = headerText;
        header.style.background = color;
    }
    modal.style.display = 'flex';
}

function closePOSModal() {
    const modal = document.getElementById('posModal') || document.getElementById('inventoryModal');
    if (modal) modal.style.display = 'none';
}

function editProduct(id, name, price, isExempt) {
    const body = document.getElementById('posModalBody');
    const footer = document.getElementById('posModalFooter');
    if (!body || !footer) return;
    
    const parsedIsExempt = (isExempt === 1 || isExempt === true);
    const basePrice = parsedIsExempt ? price : (price / 1.15).toFixed(2);

    openPOSModal("EDIT PRODUCT", "#2563eb");

    body.innerHTML = `
        <label style="display:block; margin-top:10px; font-weight:bold; font-size:11px; color:gray;">NAME</label>
        <input type="text" id="editName" value="${name}" style="width:100%; padding:10px; margin-bottom:10px; box-sizing:border-box;">
        <label style="display:block; margin-top:10px; font-weight:bold; font-size:11px; color:gray;">BASE PRICE (EXCL. VAT)</label>
        <input type="number" id="editPrice" step="0.01" value="${basePrice}" style="width:100%; padding:10px; box-sizing:border-box;">
        <p style="font-weight:bold; text-align:center; margin-top:15px;">IS THIS VAT EXEMPT?</p>
    `;

    footer.innerHTML = `
        <div style="display:flex; gap:10px; width:100%;">
            <button onclick="saveEdit(${id}, 1)" style="background:#0ea5e9; color:white; border:none; padding:12px; border-radius:5px; flex:1; font-weight:bold; cursor:pointer;">YES (Exempt)</button>
            <button onclick="saveEdit(${id}, 0)" style="background:#64748b; color:white; border:none; padding:12px; border-radius:5px; flex:1; font-weight:bold; cursor:pointer;">NO (15% VAT)</button>
        </div>
    `;
}

async function saveEdit(id, isExemptInt) {
    const n = document.getElementById('editName').value.trim();
    const p = parseFloat(document.getElementById('editPrice').value) || 0;
    const finalPrice = (isExemptInt === 1) ? p : (p * 1.15);
    const auditorName = (window.activeCashier && window.activeCashier.cashier_name) ? window.activeCashier.cashier_name : "System Manager";

    const res = await fetch('/api/admin/edit-product', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ 
            product_id: id, 
            new_name: n, 
            new_price: parseFloat(finalPrice.toFixed(2)), 
            is_vat_exempt: isExemptInt,
            user_name: auditorName
        })
    });

    if (res.ok) { 
        closePOSModal(); 
        await loadProducts(); 
    }
}

function calculatePreview() {
    const basePrice = parseFloat(document.getElementById('newPrice').value) || 0;
    const isExempt = document.getElementById('newVatExempt').checked;
    
    const shelfPrice = isExempt ? basePrice : (basePrice * 1.15);
    const previewEl = document.getElementById('pricePreview');
    if (previewEl) previewEl.innerText = `Shelf Price: E${shelfPrice.toFixed(2)}`;
}

async function addNewProduct() {
    const name = document.getElementById('newName').value.trim();
    const stock = parseInt(document.getElementById('newStock').value) || 0;
    const basePrice = parseFloat(document.getElementById('newPrice').value);
    const isExempt = document.getElementById('newVatExempt').checked;

    if (!name || isNaN(basePrice)) return alert("⚠️ Please fill all fields correctly.");

    const shelfPrice = isExempt ? basePrice : (basePrice * 1.15);

    const res = await fetch('/api/admin/add-product', { 
        method: 'POST', 
        headers: {'Content-Type': 'application/json'}, 
        body: JSON.stringify({ 
            name: name, 
            stock: stock, 
            price: parseFloat(shelfPrice.toFixed(2)), 
            is_vat_exempt: isExempt ? 1 : 0 
        }) 
    });
    
    if (res.ok) { 
        alert(`✅ Added! Final Shelf Price: E${shelfPrice.toFixed(2)}`);
        await loadProducts(); 
    }
}