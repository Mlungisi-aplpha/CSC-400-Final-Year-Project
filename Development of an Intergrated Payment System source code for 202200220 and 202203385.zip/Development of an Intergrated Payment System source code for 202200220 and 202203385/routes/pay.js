app.post('/api/pay', async (req, res) => {
    // Log data to terminal to verify what is arriving
    console.log("Data arriving at server:", req.body);

    const connection = await db.getConnection(); 
    try {
        // Start explicit database transaction block
        await connection.beginTransaction();

        // ALIGNMENT: Maps keys from the index.html payload parameters safely
        const total_amount = parseFloat(req.body.amount || req.body.total_amount) || 0;
        const payment_method = req.body.method || req.body.payment_method || 'Cash';
        const customer_phone = req.body.phone || req.body.customer_phone || 'CASH';
        const items = req.body.items || [];
        const cashier_id = req.body.cashier_id || null;
        const cashier_name = req.body.cashier_name || 'Terminal';

        // Safety check for empty carts
        if (total_amount <= 0 || items.length === 0) {
            throw new Error('Transaction rejected: Cart or total amount is invalid.');
        }

        // 🌟 1. HANDSHAKE VERIFICATION STEP (Optional: uncomment if using payment simulator)
        // const paymentGateway = require('./payment');
        // await paymentGateway.simulateHandshake(total_amount, payment_method, customer_phone);

        // 🌟 2. PRE-SALE STOCK LEVEL ASSESSMENT LOOP
        for (let item of items) {
            const [rows] = await connection.query('SELECT quantity FROM stock WHERE product_id = ?', [item.id]);
            const currentStock = rows[0]?.quantity || 0;
            if (currentStock < item.qty) {
                throw new Error(`INSUFFICIENT STOCK: ${item.name} (Available: ${currentStock}, Requested: ${item.qty})`);
            }
        }

        // Calculate tax (15% standard Eswatini rate)
        const subtotal = total_amount / 1.15;
        const tax_amount = total_amount - subtotal;

        // 🌟 3. INSERT INTO SALES TABLE (Handles dual field names for tax columns safely)
        const [result] = await connection.query(
            `INSERT INTO sales (total_amount, tax_amount, vat_amount, payment_method, customer_phone, cashier_id, sale_date) 
             VALUES (?, ?, ?, ?, ?, ?, NOW())`,
            [total_amount, tax_amount, tax_amount, payment_method, customer_phone, cashier_id]
        );
        const saleId = result.insertId;

        // 🌟 4. COMMIT ITEMS AND DEDUCT STOCK PER ROW
        for (let item of items) {
            // Write record line to inventory log
            await connection.query(
                'INSERT INTO sales_items (sale_id, product_id, qty_sold, price_per_unit) VALUES (?, ?, ?, ?)', 
                [saleId, item.id, item.qty, item.price]
            );
            
            // Deduct from master stock table
            await connection.query(
                'UPDATE stock SET quantity = quantity - ? WHERE product_id = ?', 
                [item.qty, item.id]
            );
        }

        // Commit transaction data changes to database
        await connection.commit();

        // Send a complete success response to trigger the print terminal window sequence
        const receiptNo = `OKS-${saleId.toString().padStart(6, '0')}`;
        
        // Use your clean receipt generator template formatting layout
        const dateStr = new Date().toLocaleString('en-GB', { hour12: true });
        const systemReceipt = `
<div style="font-family:'Courier New', monospace; width:300px; padding:15px; background:#fff; color:#000; border:1px solid #ddd; line-height:1.2;">
    <center>
        <h1 style="margin:0; color:#e31e24; font-size:40px; letter-spacing:-2px;">OK</h1>
        <b style="font-size:16px; letter-spacing:2px;">SUPERMARKET</b><br>
        <small>Matsapha, Eswatini</small><br>
        <small>TIN: 100-234-567 | TEL: 2518 0000</small>
    </center>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:12px;">
        <tr><td>Date:</td><td align="right">${dateStr}</td></tr>
        <tr><td>Receipt:</td><td align="right"><b>${receiptNo}</b></td></tr>
        <tr><td>Cashier:</td><td align="right">${cashier_name}</td></tr>
        <tr><td>Method:</td><td align="right">${payment_method}</td></tr>
        ${customer_phone !== 'CASH' ? `<tr><td>Ref/Phone:</td><td align="right">${customer_phone}</td></tr>` : ''}
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:13px; border-collapse:collapse;">
        <tr style="border-bottom:1px solid #000;"><th align="left">Item</th><th align="center">Qty</th><th align="right">Total</th></tr>
        ${items.map(i => `<tr><td style="padding-top:5px;">${i.name.substring(0, 18)}</td><td align="center">${i.qty}</td><td align="right">E${(i.price * i.qty).toFixed(2)}</td></tr>`).join('')}
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:14px;">
        <tr><td>Subtotal (Excl. VAT):</td><td align="right">E${subtotal.toFixed(2)}</td></tr>
        <tr><td>Add: VAT (15%):</td><td align="right">E${tax_amount.toFixed(2)}</td></tr>
        <tr style="font-size:18px; font-weight:bold;"><td style="padding-top:10px; border-top:1px solid #000;">OVERALL TOTAL:</td><td align="right" style="padding-top:10px; border-top:1px solid #000;">E${total_amount.toFixed(2)}</td></tr>
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <center style="font-size:11px; margin-top:10px;">TAX INVOICE<br>**** THANK YOU FOR SHOPPING ****<br>NO REFUNDS WITHOUT RECEIPT</center>
</div>`;

        res.json({ 
            status: 'success', 
            receipt: systemReceipt,
            saleId: saleId 
        });

    } catch (err) {
        // Rollback any queries executed during block failure states
        await connection.rollback();
        console.error("MySQL Error encountered:", err.message);
        
        // Forward failure strings (like text thrown by your database before-insert triggers) to UI
        res.status(400).json({ 
            status: 'error', 
            message: err.message 
        });
    } finally {
        // Return resource back to open connection pool
        connection.release();
    }
});