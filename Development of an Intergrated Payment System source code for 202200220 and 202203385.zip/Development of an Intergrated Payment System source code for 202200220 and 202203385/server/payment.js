module.exports = {
  simulateHandshake(amount, method, phone) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const cleanMethod = method ? String(method).trim() : '';
        const cleanPhone = phone ? String(phone).trim() : '';
        const numericAmount = parseFloat(amount) || 0;

        if (['Cash', 'Bank Card', 'Card'].includes(cleanMethod)) {
          return resolve({ transactionId: `tx_pos_${Date.now()}`, timestamp: new Date().toISOString(), message: `Local payment via ${cleanMethod} cleared successfully.`, amount: numericAmount });
        }

        if (!cleanPhone || cleanPhone.length !== 8 || isNaN(cleanPhone)) {
          return reject(new Error('❌ Gateway Error: Phone number must be exactly 8 digits long.'));
        }

        const prefix = cleanPhone.substring(0, 2);
        if (['MoMo', 'MTN MoMo'].includes(cleanMethod) && prefix !== '76' && prefix !== '78') {
          return reject(new Error('❌ Gateway Error: MTN MoMo requires numbers starting with 76 or 78.'));
        } else if (cleanMethod === 'eMali' && prefix !== '79') {
          return reject(new Error('❌ Gateway Error: eMali requires numbers starting with 79.'));
        } else if (['InstaCash', 'Unayo'].includes(cleanMethod) && prefix !== '78' && prefix !== '79') {
          return reject(new Error(`❌ Gateway Error: ${cleanMethod} requires numbers starting with 78 or 79.`));
        } else if (!['MoMo', 'MTN MoMo', 'eMali', 'InstaCash', 'Unayo'].includes(cleanMethod)) {
          return reject(new Error(`❌ Gateway Error: [${cleanMethod}] is not registered.`));
        }

        console.log(`📡 [GATEWAY] Verified ${cleanMethod} for (+268) ${cleanPhone}`);
        resolve({ transactionId: `tx_api_${Date.now()}`, timestamp: new Date().toISOString(), message: `Handshake successful.`, amount: numericAmount });
      }, 300);
    });
  }
};