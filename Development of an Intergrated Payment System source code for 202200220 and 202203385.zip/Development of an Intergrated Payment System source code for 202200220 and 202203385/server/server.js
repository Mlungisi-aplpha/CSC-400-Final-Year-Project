require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcrypt');
const db = require('./db');
const paymentGateway = require('./payment');

const app = express();
const isDev = (process.env.NODE_ENV || 'development') === 'development';

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use(session({
    secret: process.env.SESSION_SECRET || 'ok-supermarket-dev-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 8 * 60 * 60 * 1000, httpOnly: true, secure: !isDev }
}));

// Auth Middleware
function requireAuth(req, res, next) { if (req.session && req.session.user) return next(); res.status(401).json({ status: 'error', message: 'Auth required' }); }
function requireAdmin(req, res, next) { if (req.session && req.session.user && req.session.user.role === 'Admin') return next(); res.status(403).json({ status: 'error', message: 'Admin access required' }); }

// ── AUDIT & LOG HELPER ──
async function writeAuditLog(userName, actionType, details) {
    try {
        await db.query(
            'INSERT INTO audit_logs (user_name, action_type, details, timestamp) VALUES (?, ?, ?, NOW())',
            [userName || 'System', actionType, details]
        );
        console.log(`[AUDIT DB] ✅ Saved: ${actionType} by ${userName}`);
    } catch (e) { 
        console.error('[AUDIT DB] ❌ Failed to write log:', e.message); 
    }
}

// ── AUTH ──
app.get('/api/session', (req, res) => {
    if (req.session && req.session.user) {
        res.json({ status: 'success', user: req.session.user });
    } else {
        res.status(401).json({ status: 'error' });
    }
});

app.post('/api/login', async (req, res) => {
    const start = Date.now();
    const username = req.body.username;
    console.log(`[AUTH] Login attempt for: ${username}`);
    try {
        const { password } = req.body;
        const [users] = await db.query('SELECT id, cashier_name, role, password FROM users WHERE username = ?', [username]);
        
        if (users.length === 0) {
            await writeAuditLog(username, 'LOGIN_FAILED', 'User not found');
            return res.status(401).json({ status: 'error', message: 'Invalid credentials' });
        }
        
        const user = users[0];
        let isMatch = (user.password && user.password.startsWith('$2')) ? await bcrypt.compare(password, user.password) : (password === user.password);
        
        if (!isMatch) {
            await writeAuditLog(username, 'LOGIN_FAILED', 'Incorrect password');
            return res.status(401).json({ status: 'error', message: 'Invalid credentials' });
        }

        req.session.user = { id: user.id, cashier_name: user.cashier_name, role: user.role };
        await writeAuditLog(user.cashier_name, 'LOGIN', `User logged in successfully`);
        
        console.log(`[AUTH] ✅ Login successful: ${user.cashier_name} (${Date.now() - start}ms)`);
        res.json({ status: 'success', user: req.session.user });
    } catch (err) { 
        console.error('[AUTH] ❌ Error:', err.message); 
        res.status(500).json({ status: 'error', message: err.message }); 
    }
});

app.post('/api/logout', async (req, res) => { 
    if (req.session.user) await writeAuditLog(req.session.user.cashier_name, 'LOGOUT', 'User logged out');
    req.session.destroy(); 
    res.json({ status: 'success' }); 
});

// ── PRODUCTS ──
app.get('/api/products', requireAuth, async (req, res) => {
    const start = Date.now();
    try {
        const [rows] = await db.query('SELECT * FROM full_inventory_view ORDER BY name ASC');
        console.log(`[DB] ✅ Fetched ${rows.length} products (${Date.now() - start}ms)`);
        res.json(rows);
    } catch (err) { 
        console.error('[DB] ❌ Error fetching products:', err.message); 
        res.status(500).json({ status: 'error', message: err.message }); 
    }
});

// ── PAYMENT & OTP ──
app.post('/api/request-otp', requireAuth, async (req, res) => {
    const start = Date.now();
    const { phone_number, provider } = req.body;
    console.log(`[OTP] Requesting OTP for ${phone_number} via ${provider}`);
    try {
        const otp = Math.floor(1000 + Math.random() * 9000);
        await db.query('INSERT INTO payment_verifications (phone_number, provider, otp_code, status) VALUES (?, ?, ?, ?)', [phone_number, provider, otp, 'pending']);
        await writeAuditLog(req.session.user.cashier_name, 'OTP_REQUEST', `Requested ${provider} OTP for ${phone_number}`);
        console.log(`[OTP] ✅ Generated OTP ${otp} (Pending) (${Date.now() - start}ms)`);
        res.json({ status: 'success', otp }); 
    } catch (err) { 
        console.error('[OTP] ❌ Error:', err.message); 
        res.status(500).json({ status: 'error', message: err.message }); 
    }
});

// ── SALES & CHECKOUT ──
app.post('/api/pay', requireAuth, async (req, res) => {
    const start = Date.now();
    const paymentMethod = req.body.payment_method;
    const cashierName = req.session.user.cashier_name;
    console.log(`\n=========================================`);
    console.log(`[SALE] 🚀 NEW SALE INITIATED: ${paymentMethod} E${req.body.total_amount}`);
    
    let connection;
    try {
        connection = await db.getConnection();
        await connection.beginTransaction();
        console.log(`[SALE] [0ms] Database transaction started.`);

        const total_amount = parseFloat(req.body.total_amount) || 0;
        const customer_phone = req.body.customer_phone || 'CASH_SALE';
        const items = req.body.items || [];
        const cashier_id = req.session.user.id;
        const otp_code = req.body.otp_code || 'BYPASS';

        if (total_amount <= 0 || items.length === 0) throw new Error('Transaction rejected: Cart empty.');

        // 1. HANDSHAKE
        console.log(`[SALE] [${Date.now() - start}ms] Checking payment gateway...`);
        await paymentGateway.simulateHandshake(total_amount, paymentMethod, customer_phone);
        console.log(`[SALE] [${Date.now() - start}ms] ✅ Gateway handshake passed.`);

        // 2. OTP VALIDATION & STATUS UPDATE
        if (paymentMethod !== 'Cash' && paymentMethod !== 'Bank Card' && otp_code !== 'BYPASS') {
            console.log(`[SALE] [${Date.now() - start}ms] Validating OTP for ${customer_phone}...`);
            const [otpRows] = await connection.query(
                'SELECT id, otp_code FROM payment_verifications WHERE phone_number = ? AND provider = ? AND status = ? ORDER BY created_at DESC LIMIT 1',
                [customer_phone, paymentMethod, 'pending']
            );

            if (otpRows.length === 0) throw new Error('❌ No pending OTP found for this number/provider.');
            if (String(otpRows[0].otp_code) !== String(otp_code)) throw new Error('❌ Invalid OTP code.');

            await connection.query('UPDATE payment_verifications SET status = ? WHERE id = ?', ['completed', otpRows[0].id]);
            console.log(`[SALE] [${Date.now() - start}ms] ✅ OTP Validated & marked completed.`);
        }

        // 3. STOCK CHECK
        console.log(`[SALE] [${Date.now() - start}ms] Checking stock levels...`);
        for (let item of items) {
            const [rows] = await connection.query('SELECT quantity FROM stock WHERE product_id = ? FOR UPDATE', [item.id]);
            const currentStock = rows[0] ? rows[0].quantity : 0;
            if (currentStock < item.qty) throw new Error(`INSUFFICIENT STOCK: ${item.name} (Available: ${currentStock})`);
        }
        console.log(`[SALE] [${Date.now() - start}ms] ✅ Stock available.`);

        // 4. TAX CALC
        const subtotal = total_amount / 1.15;
        const tax_amount = total_amount - subtotal;

        // 5. INSERT SALE
        const [result] = await connection.query(
            'INSERT INTO sales (total_amount, tax_amount, vat_amount, payment_method, customer_phone, cashier_id, sale_date) VALUES (?, ?, ?, ?, ?, ?, NOW())',
            [total_amount, tax_amount, tax_amount, paymentMethod, customer_phone !== 'CASH_SALE' ? customer_phone : null, cashier_id]
        );
        const saleId = result.insertId;
        console.log(`[SALE] [${Date.now() - start}ms] ✅ Sale record #${saleId} created.`);

        // 6. DEDUCT STOCK & RECORD MOVEMENTS
        for (let item of items) {
            await connection.query('INSERT INTO sales_items (sale_id, product_id, qty_sold, price_per_unit) VALUES (?, ?, ?, ?)', [saleId, item.id, item.qty, item.price]);
            await connection.query('UPDATE stock SET quantity = quantity - ? WHERE product_id = ?', [item.qty, item.id]);
            await connection.query('INSERT INTO stock_movements (product_id, movement_type, quantity, reference_id, created_by, movement_date) VALUES (?, ?, ?, ?, ?, NOW())', [item.id, 'SALE', item.qty, saleId, cashier_id]);
        }
        console.log(`[SALE] [${Date.now() - start}ms] ✅ Items recorded & stock deducted.`);

        await connection.commit();
        console.log(`[SALE] [${Date.now() - start}ms] ✅ TRANSACTION COMMITTED.`);

        // 7. AUDIT LOG TO DB
        await writeAuditLog(cashierName, 'SALE', `Completed Sale #${saleId} - E${total_amount.toFixed(2)} via ${paymentMethod}`);

        // 8. RECEIPT GENERATION
        const receiptNo = 'OKS-' + String(saleId).padStart(6, '0');
        const dateStr = new Date().toLocaleString('en-GB', { hour12: true });
        
        let itemRows = '';
        for (let i of items) {
            itemRows += `<tr><td style="padding-top:5px;">${i.name.substring(0, 18)}</td><td align="center">${i.qty}</td><td align="right">E${(i.price * i.qty).toFixed(2)}</td></tr>`;
        }

        let phoneRow = customer_phone !== 'CASH_SALE' ? `<tr><td>Ref/Phone:</td><td align="right">${customer_phone}</td></tr>` : '';

        const systemReceipt = `
<div style="font-family:'Courier New', monospace; width:300px; padding:15px; background:#fff; color:#000; border:1px solid #ddd; line-height:1.2;">
    <center>
        <h1 style="margin:0; color:#e31e24; font-size:40px; letter-spacing:-2px;">OK</h1>
        <b style="font-size:16px; letter-spacing:2px;">SUPERMARKET</b><br>
        <small>Matsapha, Eswatini</small><br>
        <small>TIN: 100-234-567 | TEL: 2518 0000</small>
    </center>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:12px;">
        <tr><td>Date:</td><td align="right">${dateStr}</td></tr>
        <tr><td>Receipt:</td><td align="right"><b>${receiptNo}</b></td></tr>
        <tr><td>Cashier:</td><td align="right">${cashierName}</td></tr>
        <tr><td>Method:</td><td align="right">${paymentMethod}</td></tr>
        ${phoneRow}
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:13px; border-collapse:collapse;">
        <tr style="border-bottom:1px solid #000;"><th align="left">Item</th><th align="center">Qty</th><th align="right">Total</th></tr>
        ${itemRows}
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <table style="width:100%; font-size:14px;">
        <tr><td>Taxable Subtotal:</td><td align="right">E${subtotal.toFixed(2)}</td></tr>
        <tr><td>Add: VAT (15%):</td><td align="right">E${tax_amount.toFixed(2)}</td></tr>
        <tr style="font-size:18px; font-weight:bold;"><td style="padding-top:10px; border-top:1px solid #000;">OVERALL TOTAL:</td><td align="right" style="padding-top:10px; border-top:1px solid #000;">E${total_amount.toFixed(2)}</td></tr>
    </table>
    <div style="border-bottom:1px dashed #000; margin:10px 0;"></div>
    <center style="font-size:11px; margin-top:10px;">(E) = Zero-Rated/Exempt Item<br>TAX INVOICE<br>**** THANK YOU FOR SHOPPING ****<br>NO REFUNDS WITHOUT RECEIPT</center>
</div>`;

        console.log(`[SALE] ✅ PROCESS COMPLETE. Total time: ${Date.now() - start}ms`);
        console.log(`=========================================\n`);
        res.json({ status: 'success', receipt: systemReceipt, saleId: saleId });

    } catch (err) {
        if (connection) await connection.rollback();
        console.error(`\n[SALE] ❌ SALE FAILED: ${err.message} (Took ${Date.now() - start}ms)`);
        console.error(`=========================================\n`);
        await writeAuditLog(cashierName, 'SALE_FAILED', `Sale failed: ${err.message}`);
        res.status(400).json({ status: 'error', message: err.message });
    } finally {
        if (connection) connection.release();
    }
});

// ── REPORTS ──
app.get('/api/admin/stats', requireAdmin, async (req, res) => {
    try {
        const [rows] = await db.query('SELECT COALESCE(SUM(total_amount), 0) as revenue, COALESCE(SUM(vat_amount), 0) as tax, COUNT(id) as transactions FROM sales WHERE DATE(sale_date) = CURDATE()');
        res.json({ status: 'success', stats: rows[0] });
    } catch (err) { res.status(500).json({ status: 'error', message: err.message }); }
});

app.get('/api/daily-sales', requireAdmin, async (req, res) => {
    try {
        const [sales] = await db.query('SELECT s.id, s.payment_method, s.total_amount, s.sale_date, u.cashier_name FROM sales s LEFT JOIN users u ON s.cashier_id = u.id WHERE DATE(s.sale_date) = CURDATE() ORDER BY s.id DESC');
        res.json({ status: 'success', sales });
    } catch (err) { res.status(500).json({ status: 'error', message: err.message }); }
});

// ── INVENTORY ──
app.post('/api/admin/add-product', requireAdmin, async (req, res) => {
    let connection;
    try {
        const { name, price, stock, is_vat_exempt } = req.body;
        connection = await db.getConnection();
        await connection.beginTransaction();
        const [result] = await connection.query('INSERT INTO products (product_name, price, original_price, is_vat_exempt) VALUES (?, ?, ?, ?)', [name, price, price, is_vat_exempt || 0]);
        await connection.query('INSERT INTO stock (product_id, quantity) VALUES (?, ?)', [result.insertId, stock || 0]);
        await connection.commit();
        await writeAuditLog(req.session.user.cashier_name, 'ADD_PRODUCT', `Added: ${name} (E${price})`);
        console.log(`[DB] ✅ Added product: ${name}`);
        res.json({ status: 'success' });
    } catch (err) { 
        if (connection) await connection.rollback();
        res.status(500).json({ status: 'error', message: err.message });
    } finally { if (connection) connection.release(); }
});

app.post('/api/admin/edit-product', requireAdmin, async (req, res) => {
    try {
        const { product_id, new_name, new_price, is_vat_exempt } = req.body;
        await db.query('UPDATE products SET product_name = ?, price = ?, original_price = ?, is_vat_exempt = ? WHERE id = ?', [new_name, new_price, new_price, is_vat_exempt, product_id]);
        await writeAuditLog(req.session.user.cashier_name, 'EDIT_PRODUCT', `Updated product #${product_id}`);
        console.log(`[DB] ✅ Updated product #${product_id}`);
        res.json({ status: 'success' });
    } catch (err) { res.status(500).json({ status: 'error', message: err.message }); }
});

app.post('/api/restock', requireAuth, async (req, res) => {
    let connection;
    try {
        const { product_id, quantity, user_name } = req.body;
        connection = await db.getConnection();
        await connection.beginTransaction();
        await connection.query('UPDATE stock SET quantity = quantity + ? WHERE product_id = ?', [quantity, product_id]);
        const [userRows] = await connection.query('SELECT id FROM users WHERE cashier_name = ?', [user_name]);
        const userId = userRows[0] ? userRows[0].id : null;
        await connection.query('INSERT INTO stock_movements (product_id, movement_type, quantity, created_by, movement_date) VALUES (?, ?, ?, ?, NOW())', [product_id, 'PURCHASE', quantity, userId]);
        await connection.commit();
        await writeAuditLog(user_name, 'RESTOCK', `Restocked #${product_id} by +${quantity}`);
        console.log(`[DB] ✅ Restocked #${product_id} by ${quantity}`);
        res.json({ status: 'success' });
    } catch (err) { 
        if (connection) await connection.rollback();
        res.status(500).json({ status: 'error', message: err.message });
    } finally { if (connection) connection.release(); }
});

app.delete('/api/admin/delete-product/:id', requireAdmin, async (req, res) => {
    try {
        await db.query('DELETE FROM products WHERE id = ?', [req.params.id]);
        await writeAuditLog(req.session.user.cashier_name, 'DELETE_PRODUCT', `Deleted product #${req.params.id}`);
        console.log(`[DB] ✅ Deleted product #${req.params.id}`);
        res.json({ status: 'success' });
    } catch (err) { res.status(500).json({ status: 'error', message: err.message }); }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`\n🚀 OK SUPERMARKET SERVER running on http://localhost:${PORT}\n⏱ Watch mode active (Instant Refresh Enabled)\n📊 Database Auditing Enabled\n`));