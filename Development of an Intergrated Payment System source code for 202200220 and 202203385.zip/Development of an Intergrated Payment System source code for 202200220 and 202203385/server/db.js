 const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '', // Put your XAMPP/MariaDB password here (usually empty)
    database: 'ok_grocer_db',
    waitForConnections: true,
    connectionLimit: 5,
    queueLimit: 0
});

module.exports = pool;