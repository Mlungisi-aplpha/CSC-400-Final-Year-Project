/**
 * OK Supermarket - Integrated Payments Interface Handshake Interceptor
 * Simulates external telecom gateway networks for Eswatini mobile wallets and banking channels.
 */
module.exports = {
  simulateHandshake(amount, method, phone) {
    // Simple simulation of a provider handshake — returns a promise
    return new Promise((resolve, reject) => {
      // Small intentional latency simulation (300ms) to emulate real network round-trips
      setTimeout(() => {
        // Safe string coercion and sanitation to protect against incoming payload malformations
        const cleanMethod = method ? String(method).trim() : '';
        const cleanPhone = phone ? String(phone).trim() : '';
        const numericAmount = parseFloat(amount) || 0;

        // Bypass validation loops entirely for non-mobile standard retail tenders
        if (['Cash', 'Bank Card', 'Card'].includes(cleanMethod)) {
          return resolve({
            transactionId: `tx_pos_${Date.now()}`,
            timestamp: new Date().toISOString(),
            message: `Local payment via ${cleanMethod} cleared successfully.`,
            amount: numericAmount
          });
        }

        // --- MOBILE CHANNELS FIELD CHECK ---
        if (!cleanPhone || cleanPhone.length !== 8 || isNaN(cleanPhone)) {
          return reject(new Error('❌ Gateway Error: Phone number must be exactly 8 digits long.'));
        }

        // Isolate the subscriber provider allocation prefix (first two numbers)
        const prefix = cleanPhone.substring(0, 2);

        // 1. MTN MoMo Verification (76 or 78 only)
        if (['MoMo', 'MTN MoMo'].includes(cleanMethod)) {
          if (prefix !== '76' && prefix !== '78') {
            return reject(new Error('❌ Gateway Error: MTN MoMo transactions require Eswatini numbers starting with 76 or 78.'));
          }
        }

        // 2. Swazi Mobile eMali Verification (79 only)
        else if (cleanMethod === 'eMali') {
          if (prefix !== '79') {
            return reject(new Error('❌ Gateway Error: Swazi Mobile eMali transactions require numbers starting with 79.'));
          }
        }

        // 3. Independent InstaCash & Standard Bank Unayo Verification (78 or 79 only)
        else if (['InstaCash', 'Unayo'].includes(cleanMethod)) {
          if (prefix !== '78' && prefix !== '79') {
            return reject(new Error(`❌ Gateway Error: ${cleanMethod} transactions require numbers starting with 78 or 79.`));
          }
        }
        
        // Catch-all safety for unsupported mobile wallets passed to the gateway interface
        else {
          return reject(new Error(`❌ Gateway Error: The payment method [${cleanMethod}] is not registered with this integration layer.`));
        }

        // Output system visibility tracing into the server console context
        console.log(`📡 [GATEWAY HANDSHAKE] Verified ${cleanMethod} connection channel for phone (+268) ${cleanPhone}`);

        // If all strict routing parameters are met, resolve the transaction handshake safely
        resolve({
          transactionId: `tx_api_${Date.now()}`,
          timestamp: new Date().toISOString(),
          message: `Handshake with ${cleanMethod} network gateway successful.`,
          amount: numericAmount
        });
      }, 300);
    });
  }
};