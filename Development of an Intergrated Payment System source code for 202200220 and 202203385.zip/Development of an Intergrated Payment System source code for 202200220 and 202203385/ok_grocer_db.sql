-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2026 at 01:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ok_grocer_db`
--
CREATE DATABASE IF NOT EXISTS `ok_grocer_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ok_grocer_db`;

-- --------------------------------------------------------

--
-- Stand-in structure for view `full_inventory_view`
-- (See below for the actual view compilation)
--
DROP VIEW IF EXISTS `full_inventory_view`;
DROP TABLE IF EXISTS `full_inventory_view`;
CREATE TABLE `full_inventory_view` (
  `id` int(11),
  `product_name` varchar(255),
  `name` varchar(255),
  `price` decimal(10,2),
  `original_price` decimal(10,2),
  `is_vat_exempt` int(4),
  `current_stock` int(11),
  `is_promo` int(1)
);

-- --------------------------------------------------------

--
-- Table structure for table `payment_verifications`
--
CREATE TABLE `payment_verifications` (
  `id` int(11) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `provider` varchar(50) NOT NULL,
  `otp_code` varchar(10) NOT NULL,
  `status` varchar(20) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_verifications`
--
INSERT INTO `payment_verifications` (`id`, `phone_number`, `provider`, `otp_code`, `status`, `created_at`) VALUES
(1, '78302779', 'InstaCash', '3642', 'pending', '2026-06-04 10:12:00'),
(2, '78302779', 'InstaCash', '3895', 'completed', '2026-06-04 10:19:57'),
(3, '78404243', 'Unayo', '6735', 'completed', '2026-06-04 10:46:23'),
(4, '76801628', 'MTN MoMo', '9565', 'pending', '2026-06-04 10:57:01'),
(5, '76801628', 'MTN MoMo', '8045', 'completed', '2026-06-04 11:02:28');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--
CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) DEFAULT NULL,
  `is_vat_exempt` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--
INSERT INTO `products` (`id`, `product_name`, `price`, `original_price`, `is_vat_exempt`) VALUES
(1, 'Milk 2L', 18.50, 18.50, 0),
(2, 'White Bread', 15.00, 15.00, 0),
(3, 'Mealies 5kg', 45.00, 45.00, 0),
(4, 'Eggs 12pk', 32.00, 32.00, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--
CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `vat_amount` decimal(10,2) NOT NULL,
  `payment_method` enum('Cash','Momo','eMali','InstaCash','Unayo','Bank Card','Card') DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `cashier_id` int(11) DEFAULT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--
INSERT INTO `sales` (`id`, `total_amount`, `vat_amount`, `payment_method`, `customer_phone`, `cashier_id`, `sale_date`) VALUES
(1, 45.00, 5.87, 'InstaCash', '78302779', 2, '2026-06-04 10:20:22'),
(2, 15.00, 1.96, 'Unayo', '78404243', 2, '2026-06-04 10:47:24'),
(3, 63.50, 8.28, 'Momo', '76801628', 2, '2026-06-04 11:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `sales_items`
--
CREATE TABLE `sales_items` (
  `id` int(11) NOT NULL,
  `sale_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `qty_sold` int(11) DEFAULT 1,
  `price_per_unit` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_items`
--
INSERT INTO `sales_items` (`id`, `sale_id`, `product_id`, `qty_sold`, `price_per_unit`) VALUES
(1, 1, 3, 1, 45.00),
(2, 2, 2, 1, 15.00),
(3, 3, 3, 1, 45.00),
(4, 3, 1, 1, 18.50);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--
CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock`
--
INSERT INTO `stock` (`id`, `product_id`, `quantity`, `last_updated`) VALUES
(1, 1, 49, '2026-06-04 11:03:16'),
(2, 2, 29, '2026-06-04 10:47:24'),
(3, 3, 98, '2026-06-04 11:03:16'),
(4, 4, 25, '2026-06-04 10:15:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cashier_name` varchar(100) NOT NULL,
  `role` enum('Cashier','Admin') DEFAULT 'Cashier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--
INSERT INTO `users` (`id`, `username`, `password`, `cashier_name`, `role`) VALUES
(1, 'admin', 'admin123', 'Head Admin', 'Admin'),
(2, 'cashier1', 'cashier123', 'Jane Doe', 'Cashier');

-- --------------------------------------------------------

--
-- Structure for view `full_inventory_view`
--
DROP TABLE IF EXISTS `full_inventory_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `full_inventory_view` AS 
SELECT 
  `p`.`id` AS `id`, 
  `p`.`product_name` AS `product_name`, 
  `p`.`product_name` AS `name`, 
  `p`.`price` AS `price`, 
  IFNULL(`p`.`original_price`, `p`.`price`) AS `original_price`, 
  IFNULL(`p`.`is_vat_exempt`, 0) AS `is_vat_exempt`, 
  IFNULL(`s`.`quantity`, 0) AS `current_stock`, 
  0 AS `is_promo` 
FROM (`products` `p` LEFT JOIN `stock` `s` ON(`p`.`id` = `s`.`product_id`));

--
-- Indexes for dumped tables
--

--
-- Indexes for table `payment_verifications`
--
ALTER TABLE `payment_verifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_sales_cashier` (`cashier_id`);

--
-- Indexes for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sale_id` (`sale_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `payment_verifications`
--
ALTER TABLE `payment_verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales_items`
--
ALTER TABLE `sales_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `fk_sales_cashier` FOREIGN KEY (`cashier_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `sales_items`
--
ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;